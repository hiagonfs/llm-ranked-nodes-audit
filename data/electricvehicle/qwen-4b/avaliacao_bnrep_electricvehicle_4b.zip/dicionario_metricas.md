# Dicionário de métricas

Menores valores indicam menor erro/distância, exceto percentuais de acerto dentro da tolerância (maiores são melhores).

| Campo | Definição |
|---|---|
| BN_KL_bits | Soma das divergências KL por linha ponderadas pela probabilidade das configurações parentais na rede bnRep (métrica original). |
| CPT_KL_media_bits | Média aritmética de KL(gold || estimada) das linhas de CPT (métrica original). |
| CPT_KL_mediana_bits / CPT_KL_p90_bits | Mediana e percentil 90 de KL por linha. |
| MAE | Média de |p_estimada - p_bnRep| sobre todas as probabilidades. |
| RMSE | Raiz da média de (p_estimada - p_bnRep)^2. |
| MSE | Média do erro ao quadrado; RMSE^2. |
| erro_maximo | Maior erro absoluto em uma entrada de CPT. |
| vies_medio | Média do erro com sinal (estimada - real) nas entradas das CPTs. |
| erro_absoluto_mediana / erro_absoluto_p90 | Mediana e percentil 90 do erro absoluto por probabilidade. |
| pct_probabilidades_erro_ate_005 / _010 | Percentual das probabilidades cujo erro absoluto é até 0,05 ou 0,10 (em pontos da escala [0,1]). |
| TVD_media / TVD_mediana | Média/mediana da distância de variação total por linha: 0,5 × soma dos erros absolutos na distribuição. Intervalo [0,1]. |
| Hellinger_media | Média por linha de sqrt(0,5 × soma((sqrt(p)−sqrt(q))²)). Intervalo [0,1]. |
| JS_media_bits / JS_p90_bits | Jensen–Shannon (bits) por linha: 0,5 KL(p||m) + 0,5 KL(q||m); m=(p+q)/2. Tem suavização numérica consistente com a KL já adotada. |
| confianca_media | Confiança autorrelatada nas linhas em que foi registrada, não é probabilidade calibrada de acerto. |
| linhas_fallback_uniforme | Número de linhas cuja origem/metadados indicam prior uniforme de contingência; não é estimativa do LLM. |

A saída `metricas_por_origem_llm_rn.csv` compara grupos **distintos** de linhas, já separados pela triagem. Não permite atribuir causalmente superioridade ao LLM ou ao Ranked Nodes.
