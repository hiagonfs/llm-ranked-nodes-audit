
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 7L) stop('Esperados 7 argumentos: nome, bif, rds, info, modo, commit, reinstalar')
nome <- args[[1]]
bif <- args[[2]]
rds <- args[[3]]
info <- args[[4]]
modo <- args[[5]]
commit <- args[[6]]
reinstalar <- (args[[7]] == 'true')
repos <- 'https://cloud.r-project.org'
options(repos = c(CRAN = repos))
# Biblioteca R local do ambiente de avaliação (Colab ou outro ambiente).
r_libs <- Sys.getenv('R_LIBS_USER', unset='')
if (nzchar(r_libs)) { dir.create(r_libs, recursive=TRUE,showWarnings=FALSE); .libPaths(c(r_libs,.libPaths())) }

# bnRep importa Rgraphviz (Bioconductor). No Colab, garantimos essa dependência primeiro.
if (!requireNamespace('Rgraphviz', quietly = TRUE)) {
  if (!requireNamespace('BiocManager', quietly = TRUE))
    utils::install.packages('BiocManager', repos = repos)
  BiocManager::install('Rgraphviz', ask = FALSE, update = FALSE)
}

if (!requireNamespace('bnlearn', quietly = TRUE)) {
  utils::install.packages('bnlearn', repos = repos)
}

if (reinstalar || !requireNamespace('bnRep', quietly = TRUE)) {
  if (modo == 'github') {
    if (!requireNamespace('pak', quietly = TRUE))
      utils::install.packages('pak', repos = repos)
    if (!requireNamespace('pak', quietly = TRUE)) stop('Não foi possível instalar pak.')
    pacote <- sprintf('manueleleonelli/bnRep@%s', commit)
    pak::pak(pacote, ask = FALSE)
  } else if (modo == 'cran') {
    utils::install.packages('bnRep', repos = repos, dependencies = NA)
  } else {
    stop(paste('Modo desconhecido:', modo))
  }
}
if (!requireNamespace('bnRep', quietly = TRUE)) stop('bnRep indisponível.')
if (!requireNamespace('bnlearn', quietly = TRUE)) stop('bnlearn indisponível.')

# data() carrega os parâmetros originais, sem refazer estimação no R.
env <- new.env(parent = baseenv())
utils::data(list = nome, package = 'bnRep', envir = env)
if (!exists(nome, envir = env, inherits = FALSE)) {
  stop(sprintf('Rede %s não encontrada em bnRep.', nome))
}
referencia <- get(nome, envir = env, inherits = FALSE)
if (!inherits(referencia, 'bn.fit')) stop('A referência não é um bn.fit.')
if (any(vapply(referencia, function(no) is.null(no$prob), logical(1))))
  stop('A rede tem nó sem CPT discreta. Escolha uma rede totalmente discreta.')

# Assinatura comprovada na documentação bnlearn: write.bif(file, fitted).
bnlearn::write.bif(bif, referencia)
saveRDS(referencia, rds)

# Auditoria simples, sem exigir pacotes adicionais.
remotesha <- utils::packageDescription('bnRep')$RemoteSha
if (is.null(remotesha)) remotesha <- 'nao_disponivel_instalacao_cran'
graph <- bnlearn::bn.net(referencia)
info_linhas <- c(
  sprintf('rede=%s', nome),
  sprintf('bnRep_version=%s', as.character(utils::packageVersion('bnRep'))),
  sprintf('bnRep_RemoteSha=%s', remotesha),
  sprintf('bnlearn_version=%s', as.character(utils::packageVersion('bnlearn'))),
  sprintf('R_version=%s', as.character(getRversion())),
  sprintf('nos=%d', length(names(referencia))),
  sprintf('arestas=%d', nrow(bnlearn::arcs(graph))),
  sprintf('classe=%s', paste(class(referencia), collapse = ',')),
  sprintf('bif=%s', bif)
)
writeLines(info_linhas, info, useBytes = TRUE)
cat(paste(info_linhas, collapse = '\n'), '\n')
